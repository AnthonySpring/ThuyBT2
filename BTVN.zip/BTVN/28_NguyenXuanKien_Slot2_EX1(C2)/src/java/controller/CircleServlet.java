/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;

@WebServlet(name = "CircleServlet", urlPatterns = {"/cal"})
public class CircleServlet extends HttpServlet {

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String radiusParam = request.getParameter("radius");
            double radius = 0;
            double area = 0;

            out.println("<html><head><title>Kết quả</title></head><body>");
            out.println("<h2>Kết quả diện tích hình tròn</h2>");

            if (radiusParam != null && !radiusParam.isEmpty()) {
                try {
                    radius = Double.parseDouble(radiusParam);
                    area = Math.PI * radius * radius;
                    DecimalFormat df = new DecimalFormat("#.##");
                    out.println("<p>Bán kính: " + radius + "</p>");
                    out.println("<p>Diện tích: " + df.format(area) + "</p>");
                } catch (NumberFormatException e) {
                    out.println("<p style='color:red;'>Vui lòng nhập số hợp lệ!</p>");
                }
            } else {
                out.println("<p style='color:red;'>Vui lòng nhập bán kính!</p>");
            }

            out.println("</body></html>");
        }
    }
}
