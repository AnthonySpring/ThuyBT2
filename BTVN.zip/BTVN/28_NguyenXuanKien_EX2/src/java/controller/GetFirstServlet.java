/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "GetFirstServlet", urlPatterns = {"/getfirst"})
public class GetFirstServlet extends HttpServlet {

    private final String rollNumber = "HE150167";

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("getfirst.jsp").forward(request, response);
    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String input = request.getParameter("number");
        String message;

        try {
            int n = Integer.parseInt(input);
            if (n <= 0) {
                message = "Input must be a positive integer";
            } else {
                if (n > rollNumber.length()) {
                    n = rollNumber.length();
                }
                String result = rollNumber.substring(0, n);
                message = "Your first " + n + " letter(s) is/are: " + result;
            }
        } catch (NumberFormatException e) {
            message = "Input string does not represent a positive integer";
        }

        request.setAttribute("message", message);
        request.getRequestDispatcher("getfirst.jsp").forward(request, response);
    }
}
